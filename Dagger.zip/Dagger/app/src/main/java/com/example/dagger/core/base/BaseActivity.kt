package com.example.dagger.core.base

import android.os.Bundle
import android.os.PersistableBundle
import androidx.lifecycle.ViewModel
import dagger.android.support.DaggerAppCompatActivity


/**
 * @author akshay
 * @desc Its Base class for all the activites in the application and it will have all the common method
 */
abstract class BaseActivity<T : ViewModel> : DaggerAppCompatActivity(){

    private lateinit var viewModel: T

    public abstract fun getViewModel(): T

    override fun onCreate(savedInstanceState: Bundle?, persistentState: PersistableBundle?) {
        super.onCreate(savedInstanceState, persistentState)
        this.viewModel = viewModel
    }

}