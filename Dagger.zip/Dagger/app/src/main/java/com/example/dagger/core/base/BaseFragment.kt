package com.example.dagger.core.base

import android.content.Context
import androidx.lifecycle.ViewModel
import dagger.android.support.DaggerFragment

/**
 * @author akshay
 * @desc Its Base class for all the fragments in the application and it will have all the common methods
 */
abstract class BaseFragment<T : ViewModel> : DaggerFragment() {

    private lateinit var  viewModel: T

    abstract fun getViewModel() : T

    override fun onAttach(context: Context) {
        super.onAttach(context)
        this.viewModel=getViewModel()
    }

    override fun onDetach() {
        super.onDetach()
    }

}