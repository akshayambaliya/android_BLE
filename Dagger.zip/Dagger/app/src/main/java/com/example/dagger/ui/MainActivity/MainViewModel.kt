package com.example.dagger.ui.MainActivity
import android.bluetooth.*
import android.bluetooth.le.BluetoothLeScanner
import android.os.Build
import android.os.Handler
import android.os.Message
import android.util.Log
import android.util.SparseArray
import androidx.annotation.RequiresApi
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.dagger.utils.SensorTagData
import java.util.*
import javax.inject.Inject

class MainViewModel @Inject constructor() : ViewModel() {
    private val TAG = "BluetoothGattActivity"


    /* Humidity Service */
    private val HUMIDITY_SERVICE: UUID = UUID.fromString("f000aa20-0451-4000-b000-000000000000")
    private val HUMIDITY_DATA_CHAR: UUID = UUID.fromString("f000aa21-0451-4000-b000-000000000000")
    private val HUMIDITY_CONFIG_CHAR: UUID = UUID.fromString("f000aa22-0451-4000-b000-000000000000")

    /* Barometric Pressure Service */
    private val PRESSURE_SERVICE: UUID = UUID.fromString("f000aa40-0451-4000-b000-000000000000")
    private val PRESSURE_DATA_CHAR: UUID = UUID.fromString("f000aa41-0451-4000-b000-000000000000")
    private val PRESSURE_CONFIG_CHAR: UUID = UUID.fromString("f000aa42-0451-4000-b000-000000000000")
    private val PRESSURE_CAL_CHAR: UUID = UUID.fromString("f000aa43-0451-4000-b000-000000000000")

    /* Client Configuration Descriptor */
    private val CONFIG_DESCRIPTOR: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    var humidityValuesMutableLiveData = MutableLiveData<String>()
    fun onCLick(id:String):String{
        System.out.println("onCLickFromViewMOdel");
        humidityValuesMutableLiveData.postValue("Hello")
        return "Hello"
    }

    @RequiresApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
    val mGattCallback: BluetoothGattCallback = object : BluetoothGattCallback() {
        /* State Machine Tracking */
        private var mState = 0
        private fun reset() {
            mState = 0
        }

        private fun advance() {
            mState++
        }

        /*
         * Send an enable command to each sensor by writing a configuration
         * characteristic.  This is specific to the SensorTag to keep power
         * low by disabling sensors you aren't using.
         */
        private fun enableNextSensor(gatt: BluetoothGatt) {
            val characteristic: BluetoothGattCharacteristic
            when (mState) {
                0 -> {
                    Log.d(TAG, "Enabling pressure cal")
                    characteristic = gatt.getService(PRESSURE_SERVICE)
                        .getCharacteristic(PRESSURE_CONFIG_CHAR)
                    characteristic.value = byteArrayOf(0x02)
                }
                1 -> {
                    Log.d(TAG, "Enabling pressure")
                    characteristic = gatt.getService(PRESSURE_SERVICE)
                        .getCharacteristic(PRESSURE_CONFIG_CHAR)
                    characteristic.value = byteArrayOf(0x01)
                }
                2 -> {
                    Log.d(TAG, "Enabling humidity")
                    characteristic = gatt.getService(HUMIDITY_SERVICE)
                        .getCharacteristic(HUMIDITY_CONFIG_CHAR)
                    characteristic.value = byteArrayOf(0x01)
                }
                else -> {
                    mHandler.sendEmptyMessage(MSG_DISMISS)
                    Log.i(TAG, "All Sensors Enabled")
                    return
                }
            }
            gatt.writeCharacteristic(characteristic)
        }

        /*
         * Read the data characteristic's value for each sensor explicitly
         */
        private fun readNextSensor(gatt: BluetoothGatt) {
            val characteristic: BluetoothGattCharacteristic
            characteristic = when (mState) {
                0 -> {
                    Log.d(TAG, "Reading pressure cal")
                    gatt.getService(PRESSURE_SERVICE)
                        .getCharacteristic(PRESSURE_CAL_CHAR)
                }
                1 -> {
                    Log.d(TAG, "Reading pressure")
                    gatt.getService(PRESSURE_SERVICE)
                        .getCharacteristic(PRESSURE_DATA_CHAR)
                }
                2 -> {
                    Log.d(TAG, "Reading humidity")
                    gatt.getService(HUMIDITY_SERVICE)
                        .getCharacteristic(HUMIDITY_DATA_CHAR)
                }
                else -> {
                    mHandler.sendEmptyMessage(MSG_DISMISS)
                    Log.i(TAG, "All Sensors Enabled")
                    return
                }
            }
            gatt.readCharacteristic(characteristic)
        }

        /*
         * Enable notification of changes on the data characteristic for each sensor
         * by writing the ENABLE_NOTIFICATION_VALUE flag to that characteristic's
         * configuration descriptor.
         */
        private fun setNotifyNextSensor(gatt: BluetoothGatt) {
            val characteristic: BluetoothGattCharacteristic
            characteristic = when (mState) {
                0 -> {
                    Log.d(TAG, "Set notify pressure cal")
                    gatt.getService(PRESSURE_SERVICE)
                        .getCharacteristic(PRESSURE_CAL_CHAR)
                }
                1 -> {
                    Log.d(TAG, "Set notify pressure")
                    gatt.getService(PRESSURE_SERVICE)
                        .getCharacteristic(PRESSURE_DATA_CHAR)
                }
                2 -> {
                    Log.d(TAG, "Set notify humidity")
                    gatt.getService(HUMIDITY_SERVICE)
                        .getCharacteristic(HUMIDITY_DATA_CHAR)
                }
                else -> {
                    mHandler.sendEmptyMessage(MSG_DISMISS)
                    return
                }
            }

            //Enable local notifications
            gatt.setCharacteristicNotification(characteristic, true)
            //Enabled remote notifications
            val desc = characteristic.getDescriptor(CONFIG_DESCRIPTOR)
            desc.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            gatt.writeDescriptor(desc)
        }

        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            Log.d(TAG, "Connection State Change: " + status + " -> " + connectionState(newState))
            if (status == BluetoothGatt.GATT_SUCCESS && newState == BluetoothProfile.STATE_CONNECTED) {
                /*
                 * Once successfully connected, we must next discover all the services on the
                 * device before we can read and write their characteristics.
                 */
                gatt.discoverServices()
                mHandler.sendMessage(Message.obtain(null, MSG_PROGRESS, "Discovering Services..."))
            } else if (status == BluetoothGatt.GATT_SUCCESS && newState == BluetoothProfile.STATE_DISCONNECTED) {
                /*
                 * If at any point we disconnect, send a message to clear the weather values
                 * out of the UI
                 */
                mHandler.sendEmptyMessage(MSG_CLEAR)
            } else if (status != BluetoothGatt.GATT_SUCCESS) {
                /*
                 * If there is a failure at any stage, simply disconnect
                 */
                gatt.disconnect()
            }
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            mHandler.sendMessage(Message.obtain(null, MSG_PROGRESS, "Enabling Sensors..."))
            /*
             * With services discovered, we are going to reset our state machine and start
             * working through the sensors we need to enable
             */reset()
          //  enableNextSensor(gatt)
            System.out.println("Service"+gatt.services.toString())
        }

        override fun onCharacteristicRead(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            status: Int
        ) {
            //For each read, pass the data up to the UI thread to update the display
            if (HUMIDITY_DATA_CHAR == characteristic.uuid) {
                mHandler.sendMessage(Message.obtain(null, MSG_HUMIDITY, characteristic))
            }
            if (PRESSURE_DATA_CHAR == characteristic.uuid) {
                mHandler.sendMessage(Message.obtain(null, MSG_PRESSURE, characteristic))
            }
            if (PRESSURE_CAL_CHAR == characteristic.uuid) {
                mHandler.sendMessage(Message.obtain(null, MSG_PRESSURE_CAL, characteristic))
            }

            //After reading the initial value, next we enable notifications
            setNotifyNextSensor(gatt)
        }

        override fun onCharacteristicWrite(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            status: Int
        ) {
            //After writing the enable flag, next we read the initial value
            readNextSensor(gatt)
        }

        override fun onCharacteristicChanged(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic
        ) {
            /*
             * After notifications are enabled, all updates from the device on characteristic
             * value changes will be posted here.  Similar to read, we hand these up to the
             * UI thread to update the display.
             */
            if (HUMIDITY_DATA_CHAR == characteristic.uuid) {
                mHandler.sendMessage(Message.obtain(null, MSG_HUMIDITY, characteristic))
            }
            if (PRESSURE_DATA_CHAR == characteristic.uuid) {
                mHandler.sendMessage(Message.obtain(null, MSG_PRESSURE, characteristic))
            }
            if (PRESSURE_CAL_CHAR == characteristic.uuid) {
                mHandler.sendMessage(Message.obtain(null, MSG_PRESSURE_CAL, characteristic))
            }
        }

        override fun onDescriptorWrite(
            gatt: BluetoothGatt,
            descriptor: BluetoothGattDescriptor,
            status: Int
        ) {
            //Once notifications are enabled, we move to the next sensor and start over with enable
            advance()
            enableNextSensor(gatt)
        }

        override fun onReadRemoteRssi(gatt: BluetoothGatt, rssi: Int, status: Int) {

        }

        private fun connectionState(status: Int): String {
            return when (status) {
                BluetoothProfile.STATE_CONNECTED -> "Connected"
                BluetoothProfile.STATE_DISCONNECTED -> "Disconnected"
                BluetoothProfile.STATE_CONNECTING -> "Connecting"
                BluetoothProfile.STATE_DISCONNECTING -> "Disconnecting"
                else -> status.toString()
            }
        }
    }

    /*
  * We have a Handler to process event results on the main thread
  */
    val MSG_HUMIDITY = 101
    val MSG_PRESSURE = 102
    val MSG_PRESSURE_CAL = 103
    val MSG_PROGRESS = 201
    val MSG_DISMISS = 202
    val MSG_CLEAR = 301
    val mHandler: Handler = object : Handler() {
        @RequiresApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
        override fun handleMessage(msg: Message) {
            val characteristic: BluetoothGattCharacteristic
            when (msg.what) {
                MSG_HUMIDITY -> {
                    characteristic = msg.obj as BluetoothGattCharacteristic
                    if (characteristic.value == null) {
                        Log.w(TAG, "Error obtaining humidity value")
                        return
                    }
                    updateHumidityValues(characteristic)
                }
                MSG_PRESSURE -> {
                    characteristic = msg.obj as BluetoothGattCharacteristic
                    if (characteristic.value == null) {
                        Log.w(TAG, "Error obtaining pressure value")
                        return
                    }
                    updatePressureValue(characteristic)
                }
                MSG_PRESSURE_CAL -> {
                    characteristic = msg.obj as BluetoothGattCharacteristic
                    if (characteristic.value == null) {
                        Log.w(TAG, "Error obtaining cal value")
                        return
                    }
                    updatePressureCals(characteristic)
                }
                MSG_PROGRESS -> {

                }
                MSG_CLEAR -> clearDisplayValues()
            }
        }
    }

    private fun clearDisplayValues() {

    }
    /* Methods to extract sensor data and update the UI */
    @RequiresApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
    private fun updateHumidityValues(characteristic: BluetoothGattCharacteristic) {
        val humidity: Double = SensorTagData.extractHumidity(characteristic)
        humidityValuesMutableLiveData.postValue(humidity.toString())
    }

    private var mPressureCals: IntArray? = null
    @RequiresApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
    private fun updatePressureCals(characteristic: BluetoothGattCharacteristic) {
        mPressureCals = SensorTagData.extractCalibrationCoefficients(characteristic)
    }

    @RequiresApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
    private fun updatePressureValue(characteristic: BluetoothGattCharacteristic) {
        if (mPressureCals == null) return
        val pressure: Double = SensorTagData.extractBarometer(characteristic, mPressureCals!!)
        val temp: Double = SensorTagData.extractBarTemperature(characteristic, mPressureCals!!)
    }

    fun getHunidityLiveData():MutableLiveData<String>{
        return  humidityValuesMutableLiveData;
    }
}