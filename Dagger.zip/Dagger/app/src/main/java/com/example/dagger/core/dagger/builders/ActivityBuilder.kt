package com.example.dagger.core.dagger.builders
import com.example.dagger.ui.MainActivity.MainActivity
import com.example.dagger.ui.MainActivity.MainActivityModule
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
abstract class ActivityBuilder {

    @ContributesAndroidInjector(modules = [MainActivityModule::class])
    abstract fun contributeMainActivity(): MainActivity

}