package com.example.dagger.utils

import android.bluetooth.BluetoothGattCharacteristic
import android.os.Build
import androidx.annotation.RequiresApi

/**
 * Conversions for sensor data values on the TI SensorTag
 */
object SensorTagData {
    @RequiresApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
    fun extractHumAmbientTemperature(c: BluetoothGattCharacteristic): Double {
        val rawT = shortSignedAtOffset(c, 0)
        return -46.85 + 175.72 / 65536 * rawT.toDouble()
    }

    @RequiresApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
    fun extractHumidity(c: BluetoothGattCharacteristic): Double {
        var a = shortUnsignedAtOffset(c, 2)
        // bits [1..0] are status bits and need to be cleared
        a = a - a % 4
        return (-6f + 125f * (a / 65535f)).toDouble()
    }

    @RequiresApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
    fun extractCalibrationCoefficients(c: BluetoothGattCharacteristic): IntArray {
        val coefficients = IntArray(8)
        coefficients[0] = shortUnsignedAtOffset(c, 0)
        coefficients[1] = shortUnsignedAtOffset(c, 2)
        coefficients[2] = shortUnsignedAtOffset(c, 4)
        coefficients[3] = shortUnsignedAtOffset(c, 6)
        coefficients[4] = shortSignedAtOffset(c, 8)
        coefficients[5] = shortSignedAtOffset(c, 10)
        coefficients[6] = shortSignedAtOffset(c, 12)
        coefficients[7] = shortSignedAtOffset(c, 14)
        return coefficients
    }

    @RequiresApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
    fun extractBarTemperature(characteristic: BluetoothGattCharacteristic, c: IntArray): Double {
        // c holds the calibration coefficients
        val t_r: Int // Temperature raw value from sensor
        val t_a: Double // Temperature actual value in unit centi degrees celsius
        t_r = shortSignedAtOffset(characteristic, 0)
        t_a = 100 * (c[0] * t_r / Math.pow(2.0, 8.0) + c[1] * Math.pow(2.0, 6.0)) / Math.pow(
            2.0,
            16.0
        )
        return t_a / 100
    }

    @RequiresApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
    fun extractBarometer(characteristic: BluetoothGattCharacteristic, c: IntArray): Double {
        // c holds the calibration coefficients
        val t_r: Int // Temperature raw value from sensor
        val p_r: Int // Pressure raw value from sensor
        val S: Double // Interim value in calculation
        val O: Double // Interim value in calculation
        val p_a: Double // Pressure actual value in unit Pascal.
        t_r = shortSignedAtOffset(characteristic, 0)
        p_r = shortUnsignedAtOffset(characteristic, 2)
        S = c[2] + c[3] * t_r / Math.pow(2.0, 17.0) + c[4] * t_r / Math.pow(
            2.0,
            15.0
        ) * t_r / Math.pow(2.0, 19.0)
        O = c[5] * Math.pow(2.0, 14.0) + c[6] * t_r / Math.pow(
            2.0,
            3.0
        ) + c[7] * t_r / Math.pow(2.0, 15.0) * t_r / Math.pow(2.0, 4.0)
        p_a = (S * p_r + O) / Math.pow(2.0, 14.0)

        //Convert pascal to in. Hg
        return p_a * 0.000296
    }

    /**
     * Gyroscope, Magnetometer, Barometer, IR temperature
     * all store 16 bit two's complement values in the awkward format
     * LSB MSB, which cannot be directly parsed as getIntValue(FORMAT_SINT16, offset)
     * because the bytes are stored in the "wrong" direction.
     *
     * This function extracts these 16 bit two's complement values.
     */
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
    private fun shortSignedAtOffset(c: BluetoothGattCharacteristic, offset: Int): Int {
        val lowerByte = c.getIntValue(BluetoothGattCharacteristic.FORMAT_UINT8, offset)
        val upperByte = c.getIntValue(
            BluetoothGattCharacteristic.FORMAT_SINT8,
            offset + 1
        ) // Note: interpret MSB as signed.
        return (upperByte shl 8) + lowerByte
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
    private fun shortUnsignedAtOffset(c: BluetoothGattCharacteristic, offset: Int): Int {
        val lowerByte = c.getIntValue(BluetoothGattCharacteristic.FORMAT_UINT8, offset)
        val upperByte = c.getIntValue(
            BluetoothGattCharacteristic.FORMAT_UINT8,
            offset + 1
        ) // Note: interpret MSB as unsigned.
        return (upperByte shl 8) + lowerByte
    }
}