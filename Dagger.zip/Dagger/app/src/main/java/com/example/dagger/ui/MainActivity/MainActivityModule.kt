package com.example.dagger.ui.MainActivity

import androidx.lifecycle.ViewModelProvider
import com.example.dagger.utils.ViewModelProviderFactory
import dagger.Module
import dagger.Provides

@Module
class MainActivityModule {

    @Provides
    fun providesViewModel() : MainViewModel{
        return MainViewModel();
    }

    @Provides
    fun provideViewModelProvider(viewModel: MainViewModel) : ViewModelProvider.Factory{
        return ViewModelProviderFactory(viewModel)
    }

}