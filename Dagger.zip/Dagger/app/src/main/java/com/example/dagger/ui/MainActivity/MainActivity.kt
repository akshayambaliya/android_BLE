package com.example.dagger.ui.MainActivity

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Message
import android.util.Log
import android.util.SparseArray
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.Toast
import androidx.annotation.RequiresApi
import com.example.dagger.R
import com.example.dagger.core.base.BaseActivity
import com.example.dagger.utils.SensorTagData
import java.util.*
import javax.inject.Inject


@SuppressLint("NewApi")
class MainActivity : BaseActivity<MainViewModel>(){
    private val TAG = "BluetoothGattActivity"

    private val DEVICE_NAME = "SensorTag"
    @Inject
    internal lateinit var viewModel: MainViewModel
    lateinit var mBluetoothAdapter:BluetoothAdapter
    lateinit var mDevices:SparseArray<BluetoothDevice>
    private var mConnectedGatt: BluetoothGatt? = null
    lateinit var mBluetoothLeScanner: BluetoothLeScanner

    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(findViewById(R.id.toolbar))
        val manager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        mBluetoothAdapter = manager.adapter
        mBluetoothLeScanner = BluetoothAdapter.getDefaultAdapter().bluetoothLeScanner
        mDevices = SparseArray()

        var button:Button = findViewById(R.id.button2)
        button.setOnClickListener{
            viewModel.onCLick("Hello")
        }
        viewModel.getHunidityLiveData().observe(this, androidx.lifecycle.Observer {
            System.out.println("Value Change")
        })
    }

    override fun onResume() {
        super.onResume()
        /*
         * We need to enforce that Bluetooth is first enabled, and take the
         * user to settings to enable it if they have not done so.
         */if (mBluetoothAdapter == null || !mBluetoothAdapter.isEnabled) {
            //Bluetooth is disabled
            val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            startActivity(enableBtIntent)

            return
        }

        /*
         * Check for Bluetooth LE Support.  In production, our manifest entry will keep this
         * from installing on these devices, but this will allow test devices or other
         * sideloads to report whether or not the feature exists.
         */if (!packageManager.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            Toast.makeText(this, "No LE Support.", Toast.LENGTH_SHORT).show()

            return
        }
    }

    override fun onPause() {
        super.onPause()
        //Make sure dialog is hidden
        //Cancel any scans in progress
        viewModel.mHandler.removeCallbacks(mStopRunnable)
        viewModel.mHandler.removeCallbacks(mStartRunnable)
        mBluetoothLeScanner.stopScan(mScanCallback)
    }

    override fun onStop() {
        super.onStop()
        //Disconnect from any active tag connection
        if (mConnectedGatt != null) {
            mConnectedGatt!!.disconnect()
            mConnectedGatt = null
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Add the "scan" option to the menu
        menuInflater.inflate(R.menu.menu, menu)
        //Add any device elements we've discovered to the overflow menu
        for (i in 0 until mDevices.size()) {
            val device = mDevices.valueAt(i)
            menu.add(0, mDevices.keyAt(i), 0, device.name)
        }
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.getItemId()) {
            R.id.action_scan -> {
                mDevices.clear()
                startScan();
                true
            }
            else -> {
                //Obtain the discovered device to connect with
                val device = mDevices[item.getItemId()]
              /*
                      * Make a connection with the device using the special LE-specific
                      * connectGatt() method, passing in a callback for GATT events
                      */mConnectedGatt = device.connectGatt(this, false, viewModel.mGattCallback)
                //Display progress UI
                viewModel.mHandler.sendMessage(
                    Message.obtain(
                        null,
                        viewModel.MSG_PROGRESS,
                        "Connecting to " + device.name + "..."
                    )
                )
                super.onOptionsItemSelected(item)
            }
        }
    }

    private val mStopRunnable = Runnable { stopScan() }
    private val mStartRunnable = Runnable { startScan() }

    private fun startScan() {
        System.out.println("startScan")
        mBluetoothLeScanner.startScan(mScanCallback)
        viewModel.mHandler.postDelayed(mStopRunnable, 10000)
    }


    private fun stopScan() {
        mBluetoothLeScanner.stopScan(mScanCallback)
    }

    /* Scan result for SDK >= 21 */
    private val mScanCallback: ScanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
         System.out.println("onScanResult")
            Log.i("callbackType", callbackType.toString())
            Log.i("result", result.toString())
            val btDevice: BluetoothDevice = result.getDevice()
/*
        * We are looking for SensorTag devices only, so validate the name
        * that each device reports before adding it to our collection
        */

                mDevices.put(btDevice.hashCode(), btDevice)
                //Update the overflow menu
                invalidateOptionsMenu()

        }

        override fun onBatchScanResults(results: List<ScanResult>) {
            System.out.println("onScanResult")
           for (sr in results) {
                Log.i("ScanResult - Results", sr.toString())
            }
        }

        override fun onScanFailed(errorCode: Int) {
            println("BLE// onScanFailed")
           Log.e("Scan Failed", "Error Code: $errorCode")
        }
    }

    override fun getViewModel(): MainViewModel {
        return viewModel
    }

}