package com.example.dagger

import com.example.dagger.core.dagger.components.DaggerMainComponent
import dagger.android.DaggerApplication

class Application : DaggerApplication() {

    companion object{

        private lateinit var instance: Application

        fun getInstance() : Application{
            return instance
        }
    }


    override fun onCreate() {
        super.onCreate()
        instance=this
    }

    override fun applicationInjector() = DaggerMainComponent.builder().create(this)
}