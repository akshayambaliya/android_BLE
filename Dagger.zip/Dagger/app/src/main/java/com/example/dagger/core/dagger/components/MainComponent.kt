package com.example.dagger.core.dagger.components


import com.example.dagger.Application
import com.example.dagger.core.dagger.builders.ActivityBuilder
import dagger.Component
import dagger.android.AndroidInjector
import dagger.android.support.AndroidSupportInjectionModule
import javax.inject.Singleton

@Singleton
@Component(modules = [AndroidSupportInjectionModule::class, ActivityBuilder::class])
interface MainComponent : AndroidInjector<Application>{

    @Component.Builder
    abstract class Builder : AndroidInjector.Builder<Application>()
}